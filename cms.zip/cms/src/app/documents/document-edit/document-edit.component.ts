import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cms-document-edit',
  templateUrl: './document-edit.component.html',
  styleUrls: ['./document-edit.component.css']
})
export class DocumentEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
